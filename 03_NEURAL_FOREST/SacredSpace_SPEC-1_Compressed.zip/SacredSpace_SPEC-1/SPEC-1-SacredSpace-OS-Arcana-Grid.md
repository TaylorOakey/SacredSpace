# SPEC-1 — SacredSpace OS & Arcana Grid

## Background
SacredSpace is a long-term, multi-generational creative + learning operating system (OS) that blends:

- A **family-safe learning spine** (skills progression, journaling, rituals, portfolios)
- A **game engine** (Arcana Grid: 4 Elements × 3 Primes = 12 archetype matrix)
- A **lore-driven “Digital Forest”** (characters, quests, artifacts, canon governance)
- **AI assistance** that is powerful but constrained (deterministic state, audit trails, canon locks)
- **Audio/atmosphere** that responds to progression (soundscapes, procedural cues)

Technical constraint: prior sessions exist as partial memory/overview but not fully retrievable transcripts. Therefore this spec defines **fresh, explicit source-of-truth schemas and mechanics** that can be implemented now, then iterated without breaking canon.

Default platform: **Supabase (Postgres + Auth + RLS + Storage + Realtime + Edge Functions)** as the hosted backbone, with local-first workflows (Obsidian vault, scripts, exports) and optional local inference.

---

## Expansion Map (All Areas)

### 1) Technical Architecture & AI Integration
- Deterministic state machine + audit log
- Agent framework (Planner / Executor / Librarian / Canon-Guard) with strict permissions
- RLS as “Law layer” (defense-in-depth)
- Optional embeddings + semantic memory via pgvector

### 2) World-Building & The Digital Forest
- Canon objects: characters, loci (places), quests, artifacts, sigils
- “12-system matrix” UI mapping (Arcana Grid)
- Lore as structured data + versioning (canon vs experimental)

### 3) Atmospheric & Sensory Design
- Event-driven sound system: milestones → sound cues
- Layered soundscapes (biome, time-of-day, archetype resonance)
- Storage for audio assets + permissions via roles/RLS

### 4) Game Engine Mechanics
- Formal math model for 4 Elements × 3 Primes
- Rules engine (turn resolution, outcomes, progression loops)
- Realtime sync hooks (dashboards, shared sessions)

---

## Two Physics Questions (Defaults Included)
1) **Single-player first or family-multi-user first?**
   - Default: **family-multi-user** from day 1 (Parent / Child / Guardian / Guest roles)

2) **Where is “canon” enforced most strongly?**
   - Default: **database-first canon** (append-only canon log + state snapshots), with Obsidian as the human-friendly mirror
