# Relevance Scoring Prompt Template (LLM)

Given a candidate node and the SacredSpace project goals, score:

- relevance (0–1)
- credibility (0–1)
- freshness (0–1)

Return strict JSON.

NODE:
{{node_json}}

PROJECT_GOALS:
{{project_goals}}

OUTPUT:
{"relevance":0.0,"credibility":0.0,"freshness":0.0}
