# Node Resurrection Prompt Template (LLM)

Purpose: Decide whether an archived/stale node should be resurrected.

INPUT:
- Node metadata + summary
- Recent user intents
- Graph context (top neighbors)

Return:
{"resurrect": true|false, "reason":"...", "boost":0.0}
