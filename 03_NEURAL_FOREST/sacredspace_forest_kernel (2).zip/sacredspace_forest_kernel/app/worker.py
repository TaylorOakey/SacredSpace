from __future__ import annotations
import asyncio
import os
import socket
import logging
from pythonjsonlogger import jsonlogger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from .db import SessionLocal
from .queue import TaskQueue
from .services.scout import github_search_repos, arxiv_search, hn_feed
from .services.ingestor import Ingestor
from .services.linker import Linker
from .services.gardener import Gardener
from .config import settings

def setup_logging():
    logger = logging.getLogger()
    logger.setLevel(settings.log_level)
    handler = logging.StreamHandler()
    handler.setFormatter(jsonlogger.JsonFormatter())
    logger.handlers = [handler]

async def handle_task(db: AsyncSession, task: dict):
    task_id = int(task["id"])
    ttype = task["task_type"]
    payload = task["payload"] or {}

    ing = Ingestor()
    linker = Linker()
    gardener = Gardener()

    if ttype == "scout.run":
        # 1) Discover
        gh = await github_search_repos(settings.scout_github_query, pages=3)
        ax = await arxiv_search(settings.scout_arxiv_query, max_results=25)
        hn = await hn_feed(settings.scout_hn_feed)

        # 2) Queue ingestion tasks
        for item in (gh + ax + hn):
            await TaskQueue.enqueue(db, "ingest.item", {
                "source": item.source,
                "source_url": item.source_url,
                "title": item.title,
                "body": item.body,
                "meta": item.meta,
            }, priority=50)

    elif ttype == "ingest.item":
        from .services.scout import DiscoveredItem
        item = DiscoveredItem(
            source=payload["source"],
            source_url=payload["source_url"],
            title=payload.get("title") or payload["source_url"],
            body=payload.get("body") or "",
            meta=payload.get("meta") or {},
        )
        node_id = await ing.ingest_item(db, item)
        await TaskQueue.enqueue(db, "link.node", {"node_id": node_id}, priority=80)

    elif ttype == "link.node":
        node_id = payload["node_id"]
        await linker.link_recent(db, node_id)

    elif ttype == "gardener.decay":
        await gardener.apply_decay(db)

    elif ttype == "gardener.prune":
        await gardener.prune(db)

    elif ttype == "gardener.resurrect":
        await gardener.resurrect_candidates(db)

    else:
        raise RuntimeError(f"Unknown task_type: {ttype}")

async def worker_loop():
    setup_logging()
    worker_id = f"{socket.gethostname()}:{os.getpid()}"
    logging.info({"event":"worker_start","worker_id":worker_id})

    while True:
        async with SessionLocal() as db:
            task = await TaskQueue.claim_next(db, worker_id)
            if not task:
                await asyncio.sleep(1.0)
                continue

            try:
                await handle_task(db, task)
                await TaskQueue.mark_done(db, int(task["id"]))
                logging.info({"event":"task_done","id":int(task["id"]), "type":task["task_type"]})
            except Exception as e:
                await TaskQueue.mark_failed(db, int(task["id"]), str(e))
                logging.exception({"event":"task_failed","id":int(task["id"]), "type":task["task_type"], "err":str(e)})

if __name__ == "__main__":
    asyncio.run(worker_loop())
