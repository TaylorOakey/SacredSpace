from __future__ import annotations
import re
import time
import logging
from dataclasses import dataclass
from typing import AsyncIterator, Dict, Any, List, Optional, Tuple
import httpx
import feedparser
from tenacity import retry, stop_after_attempt, wait_exponential_jitter

from ..config import settings

GITHUB_API = "https://api.github.com"

@dataclass
class DiscoveredItem:
    source: str
    source_url: str
    title: str
    body: str | None = None
    meta: Dict[str, Any] | None = None

def _parse_link_header(link: str) -> dict:
    # Link: <...>; rel="next", <...>; rel="last"
    out = {}
    for part in link.split(","):
        m = re.search(r'<([^>]+)>;\s*rel="([^"]+)"', part.strip())
        if m:
            out[m.group(2)] = m.group(1)
    return out

class RateLimit(Exception): ...

@retry(stop=stop_after_attempt(6), wait=wait_exponential_jitter(initial=1, max=60))
async def _github_get(url: str, headers: dict) -> httpx.Response:
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        r = await client.get(url, headers=headers)
        # Primary + secondary rate limits: honor Retry-After or x-ratelimit-reset citeturn0search0
        if r.status_code in (403, 429):
            retry_after = r.headers.get("retry-after")
            if retry_after:
                raise RateLimit(f"retry-after {retry_after}")
            reset = r.headers.get("x-ratelimit-reset")
            if reset:
                raise RateLimit(f"ratelimit-reset {reset}")
        r.raise_for_status()
        return r

async def github_search_repos(query: str, per_page: int = 50, pages: int = 3) -> List[DiscoveredItem]:
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": settings.github_user_agent,
    }
    if settings.github_token:
        headers["Authorization"] = f"Bearer {settings.github_token}"

    url = f"{GITHUB_API}/search/repositories?q={httpx.QueryParams({'q': query})['q']}&per_page={per_page}"
    items: List[DiscoveredItem] = []

    for _ in range(pages):
        try:
            r = await _github_get(url, headers)
        except RateLimit as e:
            # Simple backoff: prefer Retry-After; else wait a minute
            logging.warning(f"GitHub rate-limited: {e}. Sleeping 60s.")
            await httpx.AsyncClient().aclose()
            time.sleep(60)
            continue

        data = r.json()
        for repo in data.get("items", []):
            items.append(DiscoveredItem(
                source="github",
                source_url=repo.get("html_url"),
                title=repo.get("full_name"),
                body=repo.get("description") or "",
                meta={
                    "stars": repo.get("stargazers_count"),
                    "forks": repo.get("forks_count"),
                    "language": repo.get("language"),
                    "updated_at": repo.get("updated_at"),
                    "license": (repo.get("license") or {}).get("spdx_id"),
                }
            ))
        links = _parse_link_header(r.headers.get("link", ""))
        if "next" not in links:
            break
        url = links["next"]

    return items

async def arxiv_search(query: str, start: int = 0, max_results: int = 25) -> List[DiscoveredItem]:
    # arXiv API is Atom; be polite with delay; slices up to 2000; max_index 30000 citeturn1search5
    base = "http://export.arxiv.org/api/query"
    url = f"{base}?search_query={httpx.QueryParams({'search_query': query})['search_query']}&start={start}&max_results={max_results}"
    async with httpx.AsyncClient(timeout=30.0) as client:
        r = await client.get(url, headers={"User-Agent": settings.github_user_agent})
        r.raise_for_status()
    feed = feedparser.parse(r.text)
    out: List[DiscoveredItem] = []
    for entry in feed.entries:
        out.append(DiscoveredItem(
            source="arxiv",
            source_url=entry.link,
            title=entry.title,
            body=(entry.summary or "").strip(),
            meta={
                "authors": [a.name for a in getattr(entry, "authors", [])],
                "published": getattr(entry, "published", None),
            }
        ))
    return out

async def hn_feed(url: str) -> List[DiscoveredItem]:
    # hnrss supports frontpage.atom and other feeds citeturn2search6
    async with httpx.AsyncClient(timeout=30.0) as client:
        r = await client.get(url, headers={"User-Agent": settings.github_user_agent})
        r.raise_for_status()
    feed = feedparser.parse(r.text)
    out: List[DiscoveredItem] = []
    for entry in feed.entries:
        out.append(DiscoveredItem(
            source="hn",
            source_url=entry.link,
            title=entry.title,
            body=getattr(entry, "summary", ""),
            meta={"published": getattr(entry, "published", None)}
        ))
    return out
