from __future__ import annotations
import math
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from ..config import settings

class Gardener:
    async def apply_decay(self, db: AsyncSession) -> int:
        # Simple exponential decay based on last_accessed_at; nodes without access decay faster.
        half_life_days = settings.decay_half_life_days
        lam = math.log(2) / max(1, half_life_days)

        q = text("""
            UPDATE forest_nodes
            SET resurrection_score = GREATEST(0, resurrection_score - (:lam * COALESCE(EXTRACT(EPOCH FROM (NOW() - COALESCE(last_accessed_at, created_at))) / 86400, 1))),
                updated_at = NOW()
        """)
        await db.execute(q, dict(lam=lam))
        await db.commit()
        # Rowcount may be -1 on some drivers; do a count for reporting.
        res = await db.execute(text("SELECT COUNT(*) FROM forest_nodes"))
        return int(res.scalar_one())

    async def prune(self, db: AsyncSession) -> int:
        # Never hard-delete; mark stale by lowering score under threshold.
        thresh = settings.prune_threshold
        q = text("""
            UPDATE forest_nodes
            SET tags = (tags || '"archived"'::jsonb),
                updated_at = NOW()
            WHERE resurrection_score < :thresh
              AND NOT (tags ? 'archived')
        """)
        res = await db.execute(q, dict(thresh=thresh))
        await db.commit()
        return res.rowcount or 0

    async def resurrect_candidates(self, db: AsyncSession) -> int:
        # Heuristic resurrection: high degree + semantic importance
        thresh = settings.resurrect_threshold
        q = text("""
            WITH degree AS (
              SELECT n.id,
                     COALESCE(src.cnt,0) + COALESCE(dst.cnt,0) AS deg
              FROM forest_nodes n
              LEFT JOIN (SELECT src_id, COUNT(*) cnt FROM forest_edges GROUP BY src_id) src ON src.src_id=n.id
              LEFT JOIN (SELECT dst_id, COUNT(*) cnt FROM forest_edges GROUP BY dst_id) dst ON dst.dst_id=n.id
            )
            UPDATE forest_nodes n
            SET resurrection_score = LEAST(1.0, resurrection_score + (0.02 * d.deg)),
                updated_at=NOW()
            FROM degree d
            WHERE n.id = d.id AND (n.tags ? 'archived') AND (LEAST(1.0, n.resurrection_score + (0.02 * d.deg))) >= :thresh
        """)
        res = await db.execute(q, dict(thresh=thresh))
        await db.commit()
        return res.rowcount or 0
