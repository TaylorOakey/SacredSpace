from __future__ import annotations
import logging
import hashlib
from typing import List, Optional, Dict, Any
from bs4 import BeautifulSoup

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from .http import fetch_text
from .llm import build_llm_provider
from .embeddings import build_embeddings_provider
from .scout import DiscoveredItem

def normalize_html_to_text(html: str) -> str:
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    text_out = soup.get_text("\n")
    text_out = "\n".join([ln.strip() for ln in text_out.splitlines() if ln.strip()])
    return text_out

def node_id_from_url(url: str) -> str:
    return hashlib.blake2b(url.encode("utf-8"), digest_size=12).hexdigest()

class Ingestor:
    def __init__(self):
        self.llm = build_llm_provider()
        self.emb = build_embeddings_provider()

    async def ingest_item(self, db: AsyncSession, item: DiscoveredItem) -> str:
        raw = await fetch_text(item.source_url)
        text_content = normalize_html_to_text(raw) if "<html" in raw.lower() else raw

        llm_res = await self.llm.extract_metadata(text_content, item.source_url)

        node_id = node_id_from_url(item.source_url)
        emb_res = self.emb.embed_text((llm_res.data.get("title") or "") + "\n" + (llm_res.data.get("summary") or ""))

        q = text("""
            INSERT INTO forest_nodes (id, title, node_type, source_url, body, tags, license, embedding, embedding_hash, updated_at)
            VALUES (:id, :title, :node_type, :source_url, :body, :tags::jsonb, :license, :embedding, :embedding_hash, NOW())
            ON CONFLICT (id) DO UPDATE SET
              title=EXCLUDED.title,
              body=EXCLUDED.body,
              tags=EXCLUDED.tags,
              license=EXCLUDED.license,
              embedding=EXCLUDED.embedding,
              embedding_hash=EXCLUDED.embedding_hash,
              updated_at=NOW()
        """)
        await db.execute(q, dict(
            id=node_id,
            title=llm_res.data.get("title") or item.title,
            node_type=item.source,
            source_url=item.source_url,
            body=llm_res.data.get("summary") or (item.body or ""),
            tags=llm_res.data.get("tags") or [item.source],
            license=llm_res.data.get("license") or (item.meta or {}).get("license"),
            embedding=emb_res.vector,
            embedding_hash=emb_res.embedding_hash,
        ))
        await db.commit()
        return node_id
