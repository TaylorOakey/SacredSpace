from __future__ import annotations
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from typing import List
from datetime import datetime, timezone
import uuid

from .db import SessionLocal, db_ping
from .models import TaskIn, TaskOut, NodeOut
from .queue import TaskQueue

app = FastAPI(title="SacredSpace Forest Kernel")

async def get_db():
    async with SessionLocal() as s:
        yield s

@app.get("/health")
async def health():
    ok = await db_ping()
    return {"ok": ok}

@app.post("/tasks", response_model=dict)
async def create_task(t: TaskIn, db: AsyncSession = Depends(get_db)):
    task_id = await TaskQueue.enqueue(db, t.task_type, t.payload, priority=t.priority, run_after=t.run_after, max_attempts=t.max_attempts)
    return {"id": task_id}

@app.get("/tasks/{task_id}", response_model=TaskOut)
async def get_task(task_id: int, db: AsyncSession = Depends(get_db)):
    q = text("SELECT * FROM task_queue WHERE id=:id")
    res = await db.execute(q, dict(id=task_id))
    row = res.mappings().first()
    if not row:
        raise HTTPException(404, "task not found")
    return dict(row)

@app.get("/nodes", response_model=List[NodeOut])
async def list_nodes(limit: int = 50, db: AsyncSession = Depends(get_db)):
    q = text("""
        SELECT id, title, node_type, source_url, body, tags, license,
               resurrection_score, decay_rate, embedding_hash, created_at, updated_at
        FROM forest_nodes
        ORDER BY updated_at DESC
        LIMIT :limit
    """)
    res = await db.execute(q, dict(limit=limit))
    return [dict(r) for r in res.mappings().all()]

@app.post("/ops/harvest", response_model=dict)
async def enqueue_harvest(db: AsyncSession = Depends(get_db)):
    # enqueue full pipeline
    await TaskQueue.enqueue(db, "scout.run", {}, priority=10)
    await TaskQueue.enqueue(db, "gardener.decay", {}, priority=200)
    await TaskQueue.enqueue(db, "gardener.prune", {}, priority=210)
    await TaskQueue.enqueue(db, "gardener.resurrect", {}, priority=220)
    return {"ok": True}
