from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = Field(alias="DATABASE_URL")

    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    github_token: str | None = Field(default=None, alias="GITHUB_TOKEN")
    github_user_agent: str = Field(default="sacredspace-forest-kernel", alias="GITHUB_USER_AGENT")

    llm_provider: str = Field(default="mock", alias="LLM_PROVIDER")
    openai_api_key: str | None = Field(default=None, alias="OPENAI_API_KEY")
    gemini_api_key: str | None = Field(default=None, alias="GEMINI_API_KEY")

    embeddings_provider: str = Field(default="local_sentence_transformers", alias="EMBEDDINGS_PROVIDER")
    sentence_transformers_model: str = Field(default="all-MiniLM-L6-v2", alias="SENTENCE_TRANSFORMERS_MODEL")

    scout_github_query: str = Field(default='agentic language:Python stars:>200', alias="SCOUT_GITHUB_QUERY")
    scout_arxiv_query: str = Field(default='cat:cs.AI', alias="SCOUT_ARXIV_QUERY")
    scout_hn_feed: str = Field(default='https://hnrss.org/frontpage.atom', alias="SCOUT_HN_FEED")

    link_similarity_threshold: float = Field(default=0.78, alias="LINK_SIMILARITY_THRESHOLD")
    link_max_edges_per_node: int = Field(default=12, alias="LINK_MAX_EDGES_PER_NODE")

    decay_half_life_days: int = Field(default=90, alias="DECAY_HALF_LIFE_DAYS")
    prune_threshold: float = Field(default=0.15, alias="PRUNE_THRESHOLD")
    resurrect_threshold: float = Field(default=0.65, alias="RESURRECT_THRESHOLD")

settings = Settings()
