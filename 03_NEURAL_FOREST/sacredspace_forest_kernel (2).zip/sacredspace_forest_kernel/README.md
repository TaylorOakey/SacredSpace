# S∆CR3DSP∆CE OS — Forest Kernel (Cathedral Cognitive Platform)

A production-oriented, runnable reference implementation that merges the two-stage deep research intents into **one coherent codebase**:

- **Scout**: discovers sources (GitHub, arXiv, Hacker News RSS) with rate-limit aware pagination.
- **Ingestor**: fetches + normalizes content into **Nodes** (Lite History, no raw media bytes).
- **Linker**: embeds nodes + links them in a semantic graph (pgvector).
- **Gardener**: decay / prune / resurrection scoring.
- **TaskQueue**: durable DB-backed queue (Postgres) using `SELECT ... FOR UPDATE SKIP LOCKED`.
- **API**: FastAPI endpoints for sessions, tasks, nodes, and ops.
- **Docker Compose**: API + Worker + Postgres (pgvector) + optional Redis.

## Quickstart (Docker)

1) Copy env template:
```bash
cp .env.example .env
```

2) Start the stack:
```bash
docker compose up --build
```

3) Open API docs:
- http://localhost:8000/docs

## Local (non-docker)

```bash
python -m venv .venv
. .venv/bin/activate  # (Windows: .venv\Scripts\activate)
pip install -r requirements.txt
uvicorn app.api:app --reload
```

Worker:
```bash
python -m app.worker
```

## Notes

- GitHub REST primary rate limits: **60/hr unauth**, **5000/hr auth**. citeturn0search0  
- GitHub secondary: keep concurrency under ~100 and honor `Retry-After` if present. citeturn0search0  
- arXiv API: encourage ~3s delay between calls; up to 2000 per slice and 30k max index in total. citeturn1search5  
- APScheduler current stable: 3.11.2 (Dec 22, 2025). citeturn2search0  
- huggingface_hub current: 1.4.1 (Feb 6, 2026). citeturn1search0  

## Structure

```
app/
  api.py
  worker.py
  config.py
  db.py
  models.py
  queue.py
  services/
    scout.py
    ingestor.py
    linker.py
    gardener.py
    llm.py
    embeddings.py
    http.py
  prompts/
    extraction.md
    relevance_scoring.md
    resurrection.md
migrations/
  001_init.sql
docker-compose.yml
```

## Safety / Canon Lock

This repo includes a **Canon Lock** pattern (server-side only system prompt + strict boundaries for tool outputs).
See `app/services/llm.py` for the policy wrapper.

